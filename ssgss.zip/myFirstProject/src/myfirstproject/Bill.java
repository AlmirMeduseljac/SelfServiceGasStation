/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirstproject;

import java.util.Scanner;


public class Bill 
{

    public static double RATE = 150.00; //dollars per quarter hour
    
        private int hours;
        private int minutes;
        private double fee;
        
//prompts the user to enter hours and minutes worked

public void inputTimeWorked()
{
    
System.out.println("Enter numbers of full hours worked");
System.out.print("Enter number of full minutes worked");
    Scanner keyboard = new Scanner(System.in);
    hours = keyboard.nextInt();
    minutes = keyboard.nextInt();
}

//computeFee uses the formal parameter minutesWorked as a local variable
//Fee is computed by using a formula private double computeFee (int hoursWorked, int minutesWorked)

private double computeFee(int hoursWorked, int minutesWorked)
{
    minutesWorked = hoursWorked*60 + minutesWorked;
    int quarterHours = minutesWorked/15;
    return quarterHours*RATE;

}
//calls a computeFee method
public void updateFee()
{
        /*although minutes is plugged in for minutesWorked and minutesWorked is changed the value od minutes is not changed.
         * hours and minutes are actual parameters or arguments plugged in for hoursWorked and minutesWorked formal parameters
         */
    fee = computeFee(hours,minutes);
    
}
//bill to be paid to the employee is output 
public void outputBill()
{
    System.out.println("Time worked");
    System.out.println(hours + " hours and" + minutes + "minutes");
    System.out.println("Rate: $" + RATE + "per quarter hour.");
    System.out.println("Amount due: $" + fee);
}
    //hours and minutes was not changed in computeFee(hours,minutes)
public void outputHoursAndMinutes()
{
   fee = computeFee(hours,minutes);
   System.out.print("Value of hours $" + hours);
   System.out.println("Value of minutes $" + minutes);
}
   //this was first project, see you next time!!   
}


/*homework1 => chapter4 programming project(animal species & grading homework)question6&question9
 * String API (google it)
 * java API math class(google it)
 */

/*When the variable is a class type, only the memory adress (or reference) where its object 
 * is locatedd is stored in the memory location assigned to the variable
 */


