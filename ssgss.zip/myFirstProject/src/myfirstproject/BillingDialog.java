/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirstproject;

/**
 *
 * @author Almir Međuseljac
 */
public class BillingDialog
{
    public static void main(String[] args) 
    {
        System.out.print("Welcome to the law offices of");
        System.out.println("Dewy, Cheatham, and Howe");
        
       Bill yourBill = new Bill();
       yourBill.inputTimeWorked();
       yourBill.updateFee();
       yourBill.outputBill();
       System.out.println("We have placed a lien on your house");
       System.out.println("It has been our pleasure to serve you");    
}
}